#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    tableWidget = new QTableWidget(0, 6, this);  // Измените количество строк на 0, чтобы динамически устанавливать строку позже.
    tableWidget->setFixedSize(800,800);
    setLayout(new QVBoxLayout(this));
    layout()->addWidget(tableWidget);
    fetchData();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::fetchData()
{
    auto reply = (new QNetworkAccessManager())->get(QNetworkRequest(QUrl("http://localhost:5000/api/ria-data")));
    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        if (reply->error() == QNetworkReply::NoError) {
            auto data = QJsonDocument::fromJson(reply->readAll()).array();
            tableWidget->setRowCount(data.size());
            for (int i = 0; i < data.size(); ++i) {
                auto obj = data[i].toObject();
                tableWidget->setItem(i, 0, new QTableWidgetItem(QString::number(obj["id"].toInt())));
                tableWidget->setItem(i, 1, new QTableWidgetItem(obj["date"].toString()));
                tableWidget->setItem(i, 2, new QTableWidgetItem(obj["title"].toString()));
                tableWidget->setItem(i, 3, new QTableWidgetItem(obj["description"].toString()));
                tableWidget->setItem(i, 4, new QTableWidgetItem(QString::number(obj["lat"].toDouble())));
                tableWidget->setItem(i, 5, new QTableWidgetItem(QString::number(obj["lon"].toDouble())));
            }
        }
        reply->deleteLater();
    });
}
